#include <iostream>
using namespace std;
#include <string>;
#include <cmath>;
#include <cctype> //tolower()

int main() {
	
	// Question:

	/*You are tasked with creating a program for a restaurant to calculate the total bill for a customer's order. 
	The program should prompt the user to enter the prices of the food items they want to order. 
	Once the user has entered all the prices, the program should calculate the total bill. 
	Additionally, if the total bill exceeds R800.00, the customer is eligible for a 10% discount on the total bill.

	Write a C++ program to implement the above requirements.Your program should include the following :

	-A prompt asking the user how many food items they want to order.
		- A loop to iterate through each food item and prompt the user to enter its price.
		- Accumulation of the total bill.
		- Calculation of the discount(if applicable) based on the total bill exceeding R800.00.
		- Display of the total bill after applying the discount(if applicable).
		- Proper error handling to ensure that the user enters valid prices(numeric values) and 
		that the number of food items is a positive integer.
		- Your program should run continuously until the user decides to exit.

		Ensure to structure your code appropriately using if - else statements, nested if - else, and while loops 
		to fulfill the requirements.
	*/

	float item_price = 0, total_bill = 0;

	int i = 1, item_quantity;

	cout << "============= Welcome to Restaurant Bill Calculator ============\n";
	

	while ( i > 0) {

		cout << "\nHow many items do you want to order? ";
		cin >> item_quantity;

		for (int count = 0; count < item_quantity; count++) {
			cout << "\nEnter the price of food item " << count + 1 << ": ";
			cin >> item_price;

			total_bill = total_bill + item_price;
		}

		if (total_bill > 800) {
			cout << "\nThe total bill before discount: R" << total_bill << endl;
			cout << "You are eligible for a 10% discount";

			float discount = total_bill - (total_bill/10);
			cout << "\nTotal Bill after discount: R" << discount << endl;
		}
		else {
			cout << "\nTotal Bill: R" << total_bill << endl;
			cout << "You are NOT eligible for a 10% discount";
		}

		string want_to_calculate;

		cout << "\n\nDo you want to calculate another bill? (yes/no): ";
		cin >> want_to_calculate;

		if (want_to_calculate == "no") {
			cout << "\nThank you for using the Restaurant Bill Calculator!\n\n";
			i = 0;
		}
		else {
			item_price = 0;
			total_bill = 0;
		}
		
	}

	system("pause");

	return 0;
}